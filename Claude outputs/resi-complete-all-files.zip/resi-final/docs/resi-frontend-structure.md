# Resi Frontend Project Structure

## Project Overview
React-based transaction management system for RESIDENCE | eXp Realty

## Directory Structure

```
resi/
├── public/
│   ├── index.html
│   ├── favicon.ico
│   └── residence-logo.png
├── src/
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── Sidebar.jsx
│   │   ├── Layout.jsx
│   │   └── ProtectedRoute.jsx
│   ├── pages/
│   │   ├── Login.jsx
│   │   ├── Dashboard.jsx
│   │   ├── SellerListingForm.jsx
│   │   ├── SellerUnderContractForm.jsx
│   │   ├── LandlordListingForm.jsx
│   │   ├── TenantLeaseForm.jsx
│   │   ├── TaskList.jsx
│   │   ├── CommissionDashboard.jsx
│   │   ├── AgentCommissionView.jsx
│   │   └── SuperUserCommissionView.jsx
│   ├── components/forms/
│   │   ├── SellerListingInputForm.jsx
│   │   ├── UnderContractForm.jsx
│   │   ├── LandlordInputForm.jsx
│   │   └── TenantInputForm.jsx
│   ├── components/tasks/
│   │   ├── TaskCard.jsx
│   │   ├── TaskList.jsx
│   │   ├── TaskFilter.jsx
│   │   └── TaskConfirmation.jsx
│   ├── components/commissions/
│   │   ├── CommissionCard.jsx
│   │   ├── CommissionCalculator.jsx
│   │   ├── AgentCommissionSummary.jsx
│   │   └── SuperUserCommissionSpreadsheet.jsx
│   ├── components/emails/
│   │   ├── EmailTemplate.jsx
│   │   ├── EmailPreview.jsx
│   │   └── EmailQueue.jsx
│   ├── services/
│   │   ├── api.js
│   │   ├── authService.js
│   │   ├── transactionService.js
│   │   ├── taskService.js
│   │   ├── commissionService.js
│   │   └── emailService.js
│   ├── hooks/
│   │   ├── useAuth.js
│   │   ├── useTransaction.js
│   │   └── useTasks.js
│   ├── utils/
│   │   ├── commissionCalculations.js
│   │   ├── dateHelpers.js
│   │   ├── formatters.js
│   │   └── constants.js
│   ├── styles/
│   │   ├── globals.css
│   │   ├── variables.css
│   │   └── components.css
│   ├── App.jsx
│   └── index.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── vite.config.js
```

## Key Pages & Components

### Authentication
- **Login.jsx** - Agent login with email/password

### Main Dashboard
- **Dashboard.jsx** - Overview of agent's transactions, tasks, commissions
- Shows at-a-glance stats: open deals, pending commissions, live listings

### Listing Management
- **SellerListingForm.jsx** - Create new seller listing
  - Address, price, anticipated dates, photographer selection
  - Generates tasks for listing prep
  
- **LandlordListingForm.jsx** - Create new rental listing
  - Landlord info, property address, listing details
  - Triggers photography task for marketing manager

### Transaction Management
- **SellerUnderContractForm.jsx** - Mark seller listing under contract
  - Buyer info, earnest money, deadlines, contingencies
  - Generates 20+ tasks based on transaction details
  - Conditional tasks (HOA approval, contingencies, etc.)

- **TenantLeaseForm.jsx** - Mark rental property under lease
  - Tenant info, lease dates, rent, agent commission
  - Generates W9 collection and invoice tasks

### Task Management
- **TaskList.jsx** - Agent's task dashboard
  - Filtered by due date, status, transaction type
  - Quick actions (mark complete, confirm, acknowledge)
  - Shared task visibility for team members

- **TaskConfirmation.jsx** - Special task UI for confirmations
  - Yes/No buttons
  - Date pickers
  - Text input for notes

### Commission Tracking
- **CommissionDashboard.jsx** - Router to personal or super-user view
  
- **AgentCommissionView.jsx** - Personal commission dashboard
  - Year-to-date earnings (closed + pending)
  - Sales volume breakdown
  - Live listings with potential earnings
  - Date range filter
  - Disclaimer about brokerage fees

- **SuperUserCommissionView.jsx** - Kelly's team dashboard
  - Sortable/filterable spreadsheet of all agents
  - Columns: sales volume, listings, potential earnings, Kelly's income
  - Dropdown to toggle between individual agent views

### Email Management
- **EmailPreview.jsx** - Preview pre-drafted emails before sending
- **EmailQueue.jsx** - Pending emails to send/review

## Component Patterns

### Form Components
- Built with controlled inputs
- Real-time validation
- Auto-save drafts to localStorage
- Error handling and user feedback

### Task Components
- Conditional rendering based on task type
- Shared task indicators
- Status badges
- Quick action buttons

### Commission Components
- Real-time commission calculations
- Cap year tracking
- eXp split logic implementation
- Sortable/filterable tables

## Styling Approach
- CSS variables for theming (RESIDENCE brand colors)
- Responsive design (mobile, tablet, desktop)
- Consistent component styling
- Accessibility considerations

## State Management
- React Context API for authentication
- Local state for forms (React hooks)
- API calls for persistent data

## Integration Points
- Backend API (Node.js/Express)
- Gmail API (email sending)
- Google Calendar API (event syncing)
- PostgreSQL database
