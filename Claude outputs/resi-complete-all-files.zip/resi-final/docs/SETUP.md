# Resi Frontend - Setup & Deployment Guide

This guide walks you through setting up your React frontend locally, pushing to GitHub, and deploying to Netlify.

## Prerequisites
- Node.js (v16 or higher) - [Download](https://nodejs.org/)
- Git - [Download](https://git-scm.com/)
- GitHub account - [Created ✓]
- Netlify account - [Create here](https://netlify.com)

## Step 1: Local Setup

### 1.1 Create the project folder
```bash
mkdir resi
cd resi
```

### 1.2 Initialize Git
```bash
git init
```

### 1.3 Create the project structure
Create these folders:
```
resi/
├── public/
├── src/
│   ├── components/
│   ├── pages/
│   ├── styles/
│   ├── services/
│   ├── utils/
│   └── App.jsx
├── package.json
├── vite.config.js
└── .gitignore
```

### 1.4 Copy files

**From this folder, copy these files to their locations:**

- `package.json` → `resi/`
- `App.jsx` → `resi/src/`
- `Login.jsx` → `resi/src/pages/`
- `Dashboard.jsx` → `resi/src/pages/`
- `Layout.jsx` → `resi/src/components/`
- `ProtectedRoute.jsx` → `resi/src/components/`
- CSS files (*.css) → `resi/src/styles/`

**Create `resi/public/index.html`:**
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Resi - Transaction Management</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/index.jsx"></script>
</body>
</html>
```

**Create `resi/src/index.jsx`:**
```jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/globals.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

**Create `resi/vite.config.js`:**
```javascript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    open: true,
  },
  build: {
    outDir: 'dist',
  },
});
```

**Create `resi/.gitignore`:**
```
node_modules/
.env
.env.local
dist/
.DS_Store
*.log
.vscode/
```

### 1.5 Install dependencies
```bash
npm install
```

### 1.6 Test locally
```bash
npm run dev
```

Your app should open at `http://localhost:3000`. You'll see the login page.

## Step 2: Push to GitHub

### 2.1 Create a new repository on GitHub
1. Go to [github.com/new](https://github.com/new)
2. **Repository name:** `resi` (or `resi-frontend`)
3. **Description:** "Transaction management system for RESIDENCE | eXp Realty"
4. **Visibility:** Private (recommended for business apps)
5. **Click:** "Create repository"

### 2.2 Push your code
After creating the repository, GitHub will show you these commands. Run them:

```bash
git add .
git commit -m "Initial commit: Add React frontend with authentication and dashboard

- Set up Vite with React 18
- Add authentication flow with JWT
- Create Layout with sidebar navigation
- Add Dashboard with key metrics
- Configure CSS variables and theming
- Add Login page with form validation

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/resi.git
git push -u origin main
```

**Replace `YOUR_USERNAME` with your GitHub username.**

### 2.3 Verify on GitHub
- Go to your repository: `github.com/YOUR_USERNAME/resi`
- You should see all your files there ✓

## Step 3: Deploy to Netlify

### 3.1 Create a Netlify account
- Go to [netlify.com](https://netlify.com)
- Sign up (you can use GitHub login for easier setup)

### 3.2 Connect your repository

**Option A: Netlify Dashboard (Recommended)**
1. Log in to Netlify
2. Click **"Add new site"** → **"Import an existing project"**
3. Choose **GitHub**
4. Authorize Netlify to access your GitHub account
5. Select your `resi` repository
6. **Build settings** should auto-fill:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
7. Click **"Deploy site"**

**Option B: Netlify CLI (Advanced)**
```bash
npm install -g netlify-cli
netlify login
netlify init
```

### 3.3 Wait for deployment
Netlify will build and deploy automatically. You'll get a URL like:
```
https://your-site-name.netlify.app
```

### 3.4 Configure environment variables
1. In Netlify dashboard, go to **Site settings** → **Build & deploy** → **Environment**
2. Add variables:
   ```
   VITE_API_URL=https://your-backend-api.com
   ```
3. Redeploy to pick up the changes

## Step 4: Backend Connection

Your frontend is now live, but it needs a backend API. You'll need to:

1. **Build the Node.js/Express backend** with these endpoints:
   - `POST /api/auth/login` - Login users
   - `GET /api/auth/me` - Verify session
   - `GET /api/dashboard/stats` - Get dashboard metrics
   - `GET /api/listings/recent` - Get recent listings
   - `GET /api/transactions/recent` - Get recent transactions

2. **Update the API URL** in your app:
   - In `App.jsx` and `Dashboard.jsx`, change API calls from `/api/...` to `https://your-api.com/api/...`
   - Or set `VITE_API_URL` environment variable

## Questions for You

Before I continue building the form components and task management, I need to clarify:

1. **Backend hosting:** Where will you host the Node.js backend? (Heroku, Railway, AWS, etc.)
2. **Database:** Do you have PostgreSQL hosted somewhere, or should I set that up guide?
3. **Email service:** For sending emails via Gmail API, have you set up credentials yet?
4. **Domain:** Do you have a custom domain for this, or use Netlify's subdomain?

For now, the frontend is ready to go live. The next components I'll build are:
- SellerListingForm (new listing creation)
- SellerUnderContractForm (under contract workflow)
- TaskList (task management and filtering)
- CommissionDashboard (commission tracking)

Let me know which you'd like me to tackle next, or if you'd like me to keep building all of them!
