# Resi Frontend - Detailed Deployment Checklist

## ✅ PHASE 1: Local Setup (15 minutes)

### Step 1.1: Install Node.js (if not already installed)
1. Go to https://nodejs.org
2. Download the **LTS version** (Long Term Support)
3. Run the installer and follow prompts
4. **Verify installation:**
   ```bash
   node --version
   npm --version
   ```
   You should see version numbers like `v18.x.x` and `9.x.x`

### Step 1.2: Create your project folder
On your computer, pick where you want to store this project. I recommend:
- **Mac:** `~/Documents/resi` or `~/Projects/resi`
- **Windows:** `C:\Users\YourName\Documents\resi` or `C:\Users\YourName\Projects\resi`

**Do this:**
1. Open Terminal (Mac) or Command Prompt/PowerShell (Windows)
2. Run these commands:
   ```bash
   mkdir resi
   cd resi
   ```

### Step 1.3: Create the folder structure
You're now inside the `resi` folder. Create these subfolders:

```bash
mkdir public
mkdir src
mkdir src/components
mkdir src/pages
mkdir src/styles
mkdir src/services
mkdir src/utils
```

After this, your folder structure should look like:
```
resi/
├── public/
├── src/
│   ├── components/
│   ├── pages/
│   ├── styles/
│   ├── services/
│   └── utils/
```

### Step 1.4: Copy files from Claude to your project

**You'll download these files from this conversation:**

**Root level files (put in `resi/`):**
- `package.json`
- `SETUP.md`
- Create `.gitignore` (see below)
- Create `vite.config.js` (see below)

**Component files (put in `resi/src/components/`):**
- `Layout.jsx`
- `ProtectedRoute.jsx`

**Page files (put in `resi/src/pages/`):**
- `Login.jsx`
- `Dashboard.jsx`

**CSS files (put in `resi/src/styles/`):**
- `globals.css`
- `variables.css`
- `auth.css`
- `dashboard.css`
- `layout.css`

**Create these new files:**

**`resi/.gitignore`** - Copy and paste this:
```
node_modules/
.env
.env.local
dist/
.DS_Store
*.log
.vscode/
```

**`resi/vite.config.js`** - Copy and paste this:
```javascript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    open: true,
  },
  build: {
    outDir: 'dist',
  },
});
```

**`resi/public/index.html`** - Copy and paste this:
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Resi - Transaction Management</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/index.jsx"></script>
</body>
</html>
```

**`resi/src/index.jsx`** - Copy and paste this:
```jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/globals.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

**`resi/src/App.jsx`** - Copy from App.jsx (already provided earlier)

### Step 1.5: Install dependencies
In Terminal/Command Prompt, make sure you're in the `resi` folder, then run:

```bash
npm install
```

**What this does:** Downloads all the libraries your app needs (React, React Router, etc.). This takes 2-3 minutes.

**When it's done**, you should see a new folder called `node_modules/` appear in your `resi` folder.

### Step 1.6: Test locally
Still in Terminal, run:

```bash
npm run dev
```

**What happens:**
- Your browser should automatically open to `http://localhost:3000`
- You should see the Resi login page
- The login form should be visible with email and password fields

**If it doesn't work:**
- Check Terminal for error messages (red text)
- Make sure all files are in the right folders
- Run `npm install` again if needed

**To stop the server:** Press `CTRL+C` in Terminal (on any OS)

---

## ✅ PHASE 2: Push to GitHub (10 minutes)

### Step 2.1: Initialize Git
In Terminal, make sure you're in the `resi` folder, then run:

```bash
git init
```

### Step 2.2: Add all files to Git
```bash
git add .
```

### Step 2.3: Create your first commit
```bash
git commit -m "Initial commit: Add React frontend with authentication and dashboard"
```

### Step 2.4: Rename branch to main
```bash
git branch -M main
```

### Step 2.5: Create repository on GitHub
1. Go to https://github.com/new
2. Fill in:
   - **Repository name:** `resi` (or `resi-frontend`)
   - **Description:** "Transaction management system for RESIDENCE | eXp Realty"
   - **Visibility:** Select **Private** (recommended for business apps)
3. Click **"Create repository"**
4. **Do NOT click anything else yet** - GitHub will show you instructions

### Step 2.6: Connect to GitHub and push
GitHub will show you a blue box with commands. Copy and paste these into Terminal:

```bash
git remote add origin https://github.com/YOUR_USERNAME/resi.git
git push -u origin main
```

**Replace `YOUR_USERNAME` with your actual GitHub username.**

**What to expect:**
- You may be asked to log in to GitHub
- Files will upload to GitHub (takes 10-30 seconds)
- Terminal will show: `Branch 'main' set up to track remote branch 'main' from 'origin'.`

### Step 2.7: Verify on GitHub
1. Go to https://github.com/YOUR_USERNAME/resi
2. You should see all your files there ✓
3. Keep this page open for the next step

---

## ✅ PHASE 3: Deploy to Netlify (10 minutes)

### Step 3.1: Log into Netlify
1. Go to https://app.netlify.com
2. Sign in with your Netlify account

### Step 3.2: Connect GitHub to Netlify
1. Click **"Add new site"** (top right button)
2. Click **"Import an existing project"**
3. Click **GitHub** (it might ask you to authorize - click "Authorize Netlify")
4. Find and click your `resi` repository
5. You should see a configuration screen

### Step 3.3: Configure build settings
Netlify should auto-fill these, but verify:
- **Branch to deploy:** `main`
- **Build command:** `npm run build`
- **Publish directory:** `dist`

If they're not filled in:
1. Click **"Edit settings"**
2. Enter the values above
3. Click **"Save"**

### Step 3.4: Deploy
Click the blue **"Deploy site"** button

**What happens next:**
- Netlify starts building your site (takes 2-3 minutes)
- You'll see a progress bar
- When done, you'll see a unique URL like: `https://your-site-name.netlify.app`

### Step 3.5: Test your live site
1. Click that URL
2. You should see your login page ✓
3. The site is now live on the internet!

### Step 3.6: Custom domain (optional)
If you want a custom domain instead of `netlify.app`:
1. In Netlify dashboard, go to **Site settings**
2. Click **Domain management**
3. Click **Add custom domain**
4. Enter your domain (e.g., `resi.yourcompany.com`)
5. Follow Netlify's DNS instructions

---

## ✅ PHASE 4: Auto-Deploy Setup (2 minutes)

### Step 4.1: Enable auto-deploy
1. In Netlify dashboard, go to **Site settings**
2. Click **Build & deploy**
3. Under **Deploy contexts**, verify:
   - **Production branch:** `main`
   - This means every time you push to GitHub, Netlify automatically rebuilds and deploys

**From now on, your workflow is:**
1. Make code changes locally
2. Run `npm run dev` to test
3. When ready, run:
   ```bash
   git add .
   git commit -m "Your commit message"
   git push
   ```
4. Netlify automatically deploys within 1-2 minutes

---

## 🎯 Summary

**You now have:**
- ✅ Local development environment working
- ✅ GitHub repository with your code
- ✅ Live website on Netlify
- ✅ Auto-deployment set up

**Your site is live at:** `https://your-netlify-url.netlify.app`

---

## ❓ Common Issues & Fixes

### "npm: command not found"
- Node.js didn't install correctly
- Restart your computer and try again
- Verify: `node --version` returns a number

### "Port 3000 already in use"
- Another app is using port 3000
- Run: `npm run dev -- --port 3001`
- Or close the other app

### "Module not found" error
- Files might be in wrong folders
- Check that all files match the folder structure shown above
- Run `npm install` again

### Netlify shows blank page or 404
- Wait 2-3 minutes for build to complete
- Check **Deploys** tab to see if build succeeded (green checkmark)
- If red X, click it to see error messages

### Changes not showing on live site
- Make sure you ran `git push` after `git commit`
- Wait 1-2 minutes for Netlify to rebuild
- Hard refresh browser: `CTRL+Shift+R` (Windows) or `CMD+Shift+R` (Mac)

---

## 📞 Next Steps

Once you confirm everything is working:
1. Let me know the live URL
2. I'll build the form components (SellerListingForm, UnderContractForm, etc.)
3. Those will push to GitHub and auto-deploy to Netlify

**Text/call me if anything gets stuck!** - 239-488-5900
