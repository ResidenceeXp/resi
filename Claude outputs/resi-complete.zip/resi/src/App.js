import React, { useState } from 'react';
import './App.css';
import ClosingConciergeDashboard from './components/ClosingConciergeDashboard';
import AdminDashboard from './components/AdminDashboard';
import BuyerInputForm from './components/BuyerInputForm';
import AgentDashboard from './components/AgentDashboard';
import LocalAssistantDashboard from './components/LocalAssistantDashboard';
import MarketingManagerDashboard from './components/MarketingManagerDashboard';
import TCDashboard from './components/TCDashboard';

function App() {
  const [activeSection, setActiveSection] = useState('closing');

  const renderSection = () => {
    switch (activeSection) {
      case 'closing':
        return <ClosingConciergeDashboard />;
      case 'admin':
        return <AdminDashboard />;
      case 'buyer-form':
        return <BuyerInputForm />;
      case 'agent':
        return <AgentDashboard />;
      case 'local-assistant':
        return <LocalAssistantDashboard />;
      case 'marketing':
        return <MarketingManagerDashboard />;
      case 'coordinator':
        return <TCDashboard />;
      default:
        return <ClosingConciergeDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900">
                RESIDENCE | eXp Realty
              </h1>
              <p className="ml-2 text-sm text-gray-500">Transaction Management</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setActiveSection('closing')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'closing'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Closing
              </button>
              <button
                onClick={() => setActiveSection('admin')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'admin'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Admin
              </button>
              <button
                onClick={() => setActiveSection('buyer-form')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'buyer-form'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Buyer
              </button>
              <button
                onClick={() => setActiveSection('agent')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'agent'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Agent
              </button>
              <button
                onClick={() => setActiveSection('local-assistant')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'local-assistant'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Assistant
              </button>
              <button
                onClick={() => setActiveSection('marketing')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'marketing'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Marketing
              </button>
              <button
                onClick={() => setActiveSection('coordinator')}
                className={`px-3 py-2 rounded text-sm ${
                  activeSection === 'coordinator'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Coordinator
              </button>
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderSection()}
      </main>
    </div>
  );
}

export default App;
