import React, { useState } from 'react';
import './App.css';
import ClosingConciergeDashboard from './components/ClosingConciergeDashboard';
import AdminDashboard from './components/AdminDashboard';
import BuyerInputForm from './components/BuyerInputForm';

function App() {
  const [activeSection, setActiveSection] = useState('closing');

  const renderSection = () => {
    switch (activeSection) {
      case 'closing':
        return <ClosingConciergeDashboard />;
      case 'admin':
        return <AdminDashboard />;
      case 'buyer-form':
        return <BuyerInputForm />;
      default:
        return <ClosingConciergeDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900">
                RESIDENCE | eXp Realty
              </h1>
              <p className="ml-2 text-sm text-gray-500">Transaction Management</p>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => setActiveSection('closing')}
                className={`px-4 py-2 rounded ${
                  activeSection === 'closing'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Closing Concierge
              </button>
              <button
                onClick={() => setActiveSection('admin')}
                className={`px-4 py-2 rounded ${
                  activeSection === 'admin'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Admin Dashboard
              </button>
              <button
                onClick={() => setActiveSection('buyer-form')}
                className={`px-4 py-2 rounded ${
                  activeSection === 'buyer-form'
                    ? 'bg-amber-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Buyer Input
              </button>
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderSection()}
      </main>
    </div>
  );
}

export default App;
