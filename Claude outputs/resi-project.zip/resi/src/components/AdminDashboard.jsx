import React, { useState } from 'react';
import { Users, TrendingUp, AlertCircle, CheckCircle2, Clock, DollarSign, BarChart3, Settings } from 'lucide-react';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedAgent, setSelectedAgent] = useState(null);

  const stats = [
    { label: 'Active Transactions', value: '24', icon: BarChart3, color: 'amber' },
    { label: 'Team Members', value: '8', icon: Users, color: 'blue' },
    { label: 'Revenue (Month)', value: '$185K', icon: DollarSign, color: 'green' },
    { label: 'Avg Days on Market', value: '32', icon: Clock, color: 'purple' },
  ];

  const agents = [
    {
      id: 1,
      name: 'Kelly Olin',
      role: 'Co-Founder & Team Leader',
      activeTransactions: 8,
      revenue: '$72,500',
      closingRate: '94%',
      recentClosings: 12,
    },
    {
      id: 2,
      name: 'Amanda Bolduc',
      role: 'Senior Agent',
      activeTransactions: 6,
      revenue: '$58,200',
      closingRate: '91%',
      recentClosings: 9,
    },
    {
      id: 3,
      name: 'Carrie Cabrera',
      role: 'Agent',
      activeTransactions: 5,
      revenue: '$32,800',
      closingRate: '87%',
      recentClosings: 6,
    },
    {
      id: 4,
      name: 'Liz Harris',
      role: 'Agent',
      activeTransactions: 5,
      revenue: '$21,500',
      closingRate: '85%',
      recentClosings: 4,
    },
  ];

  const recentTransactions = [
    { id: 1, property: '123 Corkscrew Rd, Estero', agent: 'Kelly Olin', status: 'In Escrow', days: 12 },
    { id: 2, property: '456 Kingston Way, Estero', agent: 'Amanda Bolduc', status: 'Pending', days: 8 },
    { id: 3, property: '789 Verdana Village Ln, Estero', agent: 'Carrie Cabrera', status: 'Pending', days: 15 },
    { id: 4, property: '321 Bonita Springs Ave, Bonita Springs', agent: 'Liz Harris', status: 'In Escrow', days: 5 },
  ];

  const alerts = [
    { type: 'warning', message: 'Inspection issues on property 456 Kingston Way - client meeting scheduled' },
    { type: 'info', message: 'Team training session on Resi system this Friday at 2pm' },
    { type: 'alert', message: 'Appraisal came in low on 789 Verdana Village Ln - re-negotiation in progress' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const colorClasses = {
            amber: 'bg-amber-50 text-amber-600',
            blue: 'bg-blue-50 text-blue-600',
            green: 'bg-green-50 text-green-600',
            purple: 'bg-purple-50 text-purple-600',
          };
          return (
            <div key={stat.label} className="bg-white rounded-lg shadow p-6">
              <div className={`${colorClasses[stat.color]} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                <Icon className="w-6 h-6" />
              </div>
              <div className="text-gray-600 text-sm mb-1">{stat.label}</div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            </div>
          );
        })}
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200 flex">
          {['overview', 'agents', 'transactions', 'alerts'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Team Performance Summary</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {agents.map(agent => (
                    <div key={agent.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                         onClick={() => setSelectedAgent(agent.id)}>
                      <div className="font-medium text-gray-900">{agent.name}</div>
                      <div className="text-xs text-gray-500 mb-2">{agent.role}</div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Active:</span>
                          <span className="font-semibold">{agent.activeTransactions}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Revenue:</span>
                          <span className="font-semibold text-green-600">{agent.revenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Close Rate:</span>
                          <span className="font-semibold text-amber-600">{agent.closingRate}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {selectedAgent && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="font-semibold text-gray-900 mb-2">
                    {agents.find(a => a.id === selectedAgent)?.name} - Detailed View
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>Recent Closings: {agents.find(a => a.id === selectedAgent)?.recentClosings}</p>
                    <p>YTD Revenue: {agents.find(a => a.id === selectedAgent)?.revenue}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Agents Tab */}
          {activeTab === 'agents' && (
            <div className="space-y-4">
              {agents.map(agent => (
                <div key={agent.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold text-gray-900">{agent.name}</h4>
                      <p className="text-sm text-gray-600">{agent.role}</p>
                    </div>
                    <button className="text-gray-400 hover:text-gray-600">
                      <Settings className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="grid grid-cols-4 gap-4 mt-4">
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Active Transactions</div>
                      <div className="text-lg font-bold text-gray-900">{agent.activeTransactions}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Revenue</div>
                      <div className="text-lg font-bold text-green-600">{agent.revenue}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Close Rate</div>
                      <div className="text-lg font-bold text-amber-600">{agent.closingRate}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Recent Closings</div>
                      <div className="text-lg font-bold text-purple-600">{agent.recentClosings}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Transactions Tab */}
          {activeTab === 'transactions' && (
            <div className="space-y-2">
              {recentTransactions.map(tx => (
                <div key={tx.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{tx.property}</div>
                    <div className="text-sm text-gray-600">{tx.agent}</div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className={`px-3 py-1 rounded text-sm font-medium ${
                      tx.status === 'In Escrow' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {tx.status}
                    </div>
                    <div className="text-sm text-gray-600">{tx.days} days</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Alerts Tab */}
          {activeTab === 'alerts' && (
            <div className="space-y-3">
              {alerts.map((alert, idx) => {
                const bgColor = {
                  warning: 'bg-yellow-50 border-yellow-200',
                  info: 'bg-blue-50 border-blue-200',
                  alert: 'bg-red-50 border-red-200',
                };
                return (
                  <div key={idx} className={`border rounded-lg p-4 ${bgColor[alert.type]}`}>
                    <div className="flex items-start">
                      {alert.type === 'warning' && <AlertCircle className="w-5 h-5 text-yellow-600 mr-3 flex-shrink-0 mt-0.5" />}
                      {alert.type === 'info' && <CheckCircle2 className="w-5 h-5 text-blue-600 mr-3 flex-shrink-0 mt-0.5" />}
                      {alert.type === 'alert' && <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />}
                      <p className="text-sm text-gray-700">{alert.message}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
