import React, { useState } from 'react';
import { Calendar, CheckCircle2, AlertCircle, FileText, Phone, Mail, Clock } from 'lucide-react';

export default function ClosingConciergeDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [checklist, setChecklist] = useState([
    { id: 1, task: 'Title Report Review', completed: true, dueDate: '2024-10-15' },
    { id: 2, task: 'Final Walkthrough Scheduled', completed: true, dueDate: '2024-10-18' },
    { id: 3, task: 'Homeowners Insurance Proof', completed: false, dueDate: '2024-10-20' },
    { id: 4, task: 'Loan Docs Review', completed: false, dueDate: '2024-10-22' },
    { id: 5, task: 'HOA Transfer & Docs', completed: false, dueDate: '2024-10-25' },
    { id: 6, task: 'Final Hazard Insurance Confirmation', completed: false, dueDate: '2024-10-28' },
  ]);

  const daysUntilClosing = 28;
  const completedTasks = checklist.filter(item => item.completed).length;
  const progressPercent = (completedTasks / checklist.length) * 100;

  const toggleTask = (id) => {
    setChecklist(checklist.map(item =>
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const contacts = [
    { name: 'Kelly Olin', role: 'Real Estate Agent', phone: '239-488-5900', email: 'kelly.olin@exprealty.com' },
    { name: 'Closing Attorney', role: 'Legal', phone: '239-555-0101', email: 'attorney@lawfirm.com' },
    { name: 'Loan Officer', role: 'Financing', phone: '239-555-0102', email: 'loan@bank.com' },
    { name: 'Title Company', role: 'Title Services', phone: '239-555-0103', email: 'title@titleco.com' },
  ];

  const documents = [
    { name: 'Purchase Agreement', status: 'Received', date: '2024-09-01' },
    { name: 'Inspection Report', status: 'Received', date: '2024-09-08' },
    { name: 'Appraisal', status: 'Received', date: '2024-09-15' },
    { name: 'Title Report', status: 'Received', date: '2024-09-22' },
    { name: 'Final Loan Approval', status: 'Pending', date: 'Expected 10-20' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Closing Concierge Dashboard</h1>
            <p className="text-gray-600 mt-1">123 Corkscrew Rd, Estero, FL 33928</p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold text-amber-500">{daysUntilClosing}</div>
            <div className="text-gray-600 flex items-center justify-end mt-1">
              <Clock className="w-4 h-4 mr-1" />
              Days until closing
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-600">Closing Preparation</span>
            <span className="font-semibold text-gray-900">{completedTasks} of {checklist.length} tasks</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-green-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200 flex">
          {['overview', 'checklist', 'contacts', 'documents'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start">
                <AlertCircle className="w-5 h-5 text-blue-600 mr-3 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-blue-900">Next Action Required</h3>
                  <p className="text-blue-700 text-sm mt-1">Please submit homeowners insurance proof by October 20th</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-green-700">{completedTasks}</div>
                  <div className="text-sm text-green-600">Tasks Completed</div>
                </div>
                <div className="bg-amber-50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-amber-700">{checklist.length - completedTasks}</div>
                  <div className="text-sm text-amber-600">Tasks Remaining</div>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-purple-700">{daysUntilClosing}</div>
                  <div className="text-sm text-purple-600">Days Remaining</div>
                </div>
              </div>
            </div>
          )}

          {/* Checklist Tab */}
          {activeTab === 'checklist' && (
            <div className="space-y-3">
              {checklist.map(item => (
                <div
                  key={item.id}
                  className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() => toggleTask(item.id)}
                >
                  <div className="w-6 h-6 rounded border-2 border-gray-300 flex items-center justify-center mr-4 flex-shrink-0">
                    {item.completed && <CheckCircle2 className="w-6 h-6 text-green-500" />}
                  </div>
                  <div className="flex-1">
                    <div className={item.completed ? 'line-through text-gray-400' : 'text-gray-900'}>
                      {item.task}
                    </div>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    {item.dueDate}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Contacts Tab */}
          {activeTab === 'contacts' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {contacts.map((contact, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg p-4">
                  <div className="font-semibold text-gray-900">{contact.name}</div>
                  <div className="text-sm text-gray-600 mb-3">{contact.role}</div>
                  <div className="flex items-center space-x-4">
                    <a href={`tel:${contact.phone}`} className="flex items-center text-amber-600 hover:text-amber-700 text-sm">
                      <Phone className="w-4 h-4 mr-1" />
                      {contact.phone}
                    </a>
                    <a href={`mailto:${contact.email}`} className="flex items-center text-amber-600 hover:text-amber-700 text-sm">
                      <Mail className="w-4 h-4 mr-1" />
                      Email
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Documents Tab */}
          {activeTab === 'documents' && (
            <div className="space-y-2">
              {documents.map((doc, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <FileText className="w-5 h-5 text-gray-400 mr-3" />
                    <div>
                      <div className="font-medium text-gray-900">{doc.name}</div>
                      <div className="text-sm text-gray-500">{doc.date}</div>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded text-sm font-medium ${
                    doc.status === 'Received'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {doc.status}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
