import React, { useState } from 'react';
import { User, Phone, Mail, DollarSign, Calendar, FileText, CheckCircle2, AlertCircle } from 'lucide-react';

export default function BuyerInputForm() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    buyerType: '',
    preApprovalAmount: '',
    downPayment: '',
    loanAmount: '',
    propertyType: '',
    priceRange: '',
    location: '',
    timelineMonths: '',
    notes: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.firstName && formData.lastName && formData.email && formData.phone) {
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
      console.log('Form submitted:', formData);
      // Reset form
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        buyerType: '',
        preApprovalAmount: '',
        downPayment: '',
        loanAmount: '',
        propertyType: '',
        priceRange: '',
        location: '',
        timelineMonths: '',
        notes: '',
      });
    }
  };

  const isFormValid = formData.firstName && formData.lastName && formData.email && formData.phone;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">New Buyer Information</h1>
        <p className="text-gray-600 mb-8">Tell us about your new buyer so we can serve them better</p>

        {submitted && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-start">
            <CheckCircle2 className="w-6 h-6 text-green-600 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-green-900">Buyer information saved!</h3>
              <p className="text-green-700 text-sm mt-1">Thank you. We'll get started on their search right away.</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Personal Information Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <User className="w-5 h-5 mr-2 text-amber-600" />
              Personal Information
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">First Name *</label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Last Name *</label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <Mail className="w-4 h-4 mr-1" />
                  Email *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <Phone className="w-4 h-4 mr-1" />
                  Phone *
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                  required
                />
              </div>
            </div>
          </div>

          {/* Buyer Profile Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Buyer Profile</h2>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">Buyer Type</label>
              <div className="space-y-2">
                {['First-Time Buyer', 'Relocating', 'Investment Property', 'Retirement/Second Home'].map(type => (
                  <label key={type} className="flex items-center">
                    <input
                      type="radio"
                      name="buyerType"
                      value={type}
                      checked={formData.buyerType === type}
                      onChange={handleChange}
                      className="w-4 h-4 text-amber-600"
                    />
                    <span className="ml-2 text-gray-700">{type}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Financing Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <DollarSign className="w-5 h-5 mr-2 text-amber-600" />
              Financing Information
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pre-Approval Amount</label>
                <input
                  type="text"
                  name="preApprovalAmount"
                  value={formData.preApprovalAmount}
                  onChange={handleChange}
                  placeholder="e.g., $450,000"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Down Payment %</label>
                <input
                  type="text"
                  name="downPayment"
                  value={formData.downPayment}
                  onChange={handleChange}
                  placeholder="e.g., 20%"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Loan Type</label>
                <select
                  name="loanAmount"
                  value={formData.loanAmount}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                >
                  <option value="">Select loan type</option>
                  <option value="conventional">Conventional</option>
                  <option value="fha">FHA</option>
                  <option value="va">VA</option>
                  <option value="cash">Cash</option>
                </select>
              </div>
            </div>
          </div>

          {/* Property Preferences Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Property Preferences</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Property Type</label>
                <select
                  name="propertyType"
                  value={formData.propertyType}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                >
                  <option value="">Select type</option>
                  <option value="single-family">Single Family Home</option>
                  <option value="condo">Condo</option>
                  <option value="townhome">Townhome</option>
                  <option value="land">Land</option>
                  <option value="commercial">Commercial</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price Range</label>
                <select
                  name="priceRange"
                  value={formData.priceRange}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                >
                  <option value="">Select range</option>
                  <option value="400-600">$400K - $600K</option>
                  <option value="600-800">$600K - $800K</option>
                  <option value="800-1000">$800K - $1M</option>
                  <option value="1000-1200">$1M - $1.2M</option>
                  <option value="1200+">$1.2M+</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Location</label>
                <select
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
                >
                  <option value="">Select area</option>
                  <option value="corkscrew">Corkscrew Corridor</option>
                  <option value="kingston">Kingston</option>
                  <option value="bonita">Bonita Springs</option>
                  <option value="naples">Naples</option>
                  <option value="fort-myers">Fort Myers</option>
                </select>
              </div>
            </div>
          </div>

          {/* Timeline Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-amber-600" />
              Timeline
            </h2>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">When do you need to move?</label>
              <select
                name="timelineMonths"
                value={formData.timelineMonths}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
              >
                <option value="">Select timeline</option>
                <option value="0-1">Less than 1 month</option>
                <option value="1-3">1-3 months</option>
                <option value="3-6">3-6 months</option>
                <option value="6-12">6-12 months</option>
                <option value="12+">12+ months or flexible</option>
              </select>
            </div>
          </div>

          {/* Notes Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-amber-600" />
              Additional Notes
            </h2>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="Any additional preferences, requirements, or notes about this buyer..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-amber-500 focus:border-amber-500 outline-none transition"
              rows="4"
            />
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="submit"
              disabled={!isFormValid}
              className={`flex-1 px-6 py-3 rounded-lg font-medium transition-colors ${
                isFormValid
                  ? 'bg-amber-600 text-white hover:bg-amber-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              Save Buyer Information
            </button>
            <button
              type="reset"
              className="px-6 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Clear Form
            </button>
          </div>

          {!isFormValid && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start">
              <AlertCircle className="w-5 h-5 text-amber-600 mr-3 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-amber-800">Please fill in all required fields (marked with *) to submit.</p>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
