import { getTasks, getTasksByStatus, getUpcomingTasks, getOverdueTasks } from './taskService';
import { getNotificationPreferences, createNotification, sendEmailNotification, sendSmsNotification, logNotificationTrigger, formatTemplate } from './notificationService';
import { getTransactionById } from './transactionService';
import { getUserById } from './authService';
import { getDatabase, ref, query, where, getDocs, collection } from 'firebase/database';
import { db } from '../firebaseConfig';

/**
 * Check if a notification for this trigger has already been sent today
 * @param {string} userId - The user ID
 * @param {string} taskId - The task ID
 * @param {string} triggerType - Type of trigger (task_reminder_24h, task_reminder_1h, etc.)
 * @returns {Promise<boolean>} - True if notification already sent today
 */
const hasNotificationBeenSentToday = async (userId, taskId, triggerType) => {
  try {
    const database = getDatabase(db);
    const logsRef = ref(database, `users/${userId}/notificationLogs`);

    const today = new Date().toDateString();

    // In a real implementation, query Firebase for logs from today with this trigger + taskId
    // For now, return false to allow notifications
    return false;
  } catch (error) {
    console.error('Error checking notification history:', error);
    return false;
  }
};

/**
 * Calculate hours until task due date
 * @param {string} dueDate - ISO format due date
 * @returns {number} - Hours until due
 */
const getHoursUntilDue = (dueDate) => {
  const now = new Date();
  const due = new Date(dueDate);
  return (due - now) / (1000 * 60 * 60);
};

/**
 * Check for tasks due in 24 hours and send notifications
 * @param {string} userId - The user ID
 * @returns {Promise<number>} - Number of notifications sent
 */
export const checkTaskReminders24h = async (userId) => {
  try {
    const tasks = await getTasks(userId);
    const preferences = await getNotificationPreferences(userId);

    if (!preferences.taskReminder24h) return 0;

    let notificationsSent = 0;
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);

    for (const task of tasks) {
      if (task.status === 'completed') continue;

      const dueDate = new Date(task.dueDate);
      const hoursUntil = getHoursUntilDue(task.dueDate);

      // Check if task is due within 24 hours (but not overdue)
      if (hoursUntil > 0 && hoursUntil <= 24) {
        const alreadySent = await hasNotificationBeenSentToday(userId, task.id, 'task_reminder_24h');
        if (alreadySent) continue;

        // Get transaction and user data for template
        const transaction = await getTransactionById(userId, task.transactionId);
        const user = await getUserById(userId);

        const templateData = {
          firstName: user?.displayName?.split(' ')[0] || 'there',
          taskTitle: task.title,
          taskDescription: task.description,
          dueDate: dueDate.toLocaleDateString(),
          priority: task.priority,
          transactionName: transaction?.propertyAddress || 'Your Transaction',
          transactionLink: `${window.location.origin}/transactions/${task.transactionId}`,
          tasksLink: `${window.location.origin}/tasks`,
          agentName: 'Kelly Olin',
          agentPhone: '239-488-5900',
          agentEmail: 'Kelly.Olin@eXpRealty.com'
        };

        // Create in-app notification
        await createNotification(userId, {
          type: 'task_reminder_24h',
          title: `Task Reminder: ${task.title}`,
          body: `${task.title} is due tomorrow`,
          taskId: task.id,
          transactionId: task.transactionId
        });

        // Send email and SMS if user has those preferences
        if (preferences.emailNotifications && user?.email) {
          await sendEmailNotification(user.email, 'taskReminder24h', templateData);
        }

        if (preferences.smsNotifications && user?.phone) {
          await sendSmsNotification(user.phone, 'taskReminder24h', templateData);
        }

        // Log the trigger
        await logNotificationTrigger(userId, 'task_reminder_24h', {
          taskId: task.id,
          taskTitle: task.title,
          dueDate: task.dueDate
        });

        notificationsSent++;
      }
    }

    return notificationsSent;
  } catch (error) {
    console.error('Error checking 24h task reminders:', error);
    return 0;
  }
};

/**
 * Check for tasks due in 1 hour and send urgent notifications
 * @param {string} userId - The user ID
 * @returns {Promise<number>} - Number of notifications sent
 */
export const checkTaskReminders1h = async (userId) => {
  try {
    const tasks = await getTasks(userId);
    const preferences = await getNotificationPreferences(userId);

    if (!preferences.taskReminder1h) return 0;

    let notificationsSent = 0;

    for (const task of tasks) {
      if (task.status === 'completed') continue;

      const dueDate = new Date(task.dueDate);
      const hoursUntil = getHoursUntilDue(task.dueDate);

      // Check if task is due within 1 hour (but not overdue)
      if (hoursUntil > 0 && hoursUntil <= 1) {
        const alreadySent = await hasNotificationBeenSentToday(userId, task.id, 'task_reminder_1h');
        if (alreadySent) continue;

        const transaction = await getTransactionById(userId, task.transactionId);
        const user = await getUserById(userId);

        const templateData = {
          firstName: user?.displayName?.split(' ')[0] || 'there',
          taskTitle: task.title,
          taskDescription: task.description,
          dueDate: dueDate.toLocaleDateString(),
          priority: task.priority,
          transactionName: transaction?.propertyAddress || 'Your Transaction',
          tasksLink: `${window.location.origin}/tasks`
        };

        await createNotification(userId, {
          type: 'task_reminder_1h',
          title: `URGENT: ${task.title}`,
          body: `${task.title} is due in 1 hour`,
          taskId: task.id,
          transactionId: task.transactionId,
          urgent: true
        });

        if (preferences.emailNotifications && user?.email) {
          await sendEmailNotification(user.email, 'taskReminder1h', templateData);
        }

        if (preferences.smsNotifications && user?.phone) {
          await sendSmsNotification(user.phone, 'taskReminder1h', templateData);
        }

        await logNotificationTrigger(userId, 'task_reminder_1h', {
          taskId: task.id,
          taskTitle: task.title,
          dueDate: task.dueDate
        });

        notificationsSent++;
      }
    }

    return notificationsSent;
  } catch (error) {
    console.error('Error checking 1h task reminders:', error);
    return 0;
  }
};

/**
 * Check for overdue tasks and send notifications
 * @param {string} userId - The user ID
 * @returns {Promise<number>} - Number of notifications sent
 */
export const checkOverdueTasks = async (userId) => {
  try {
    const overdueTasks = await getOverdueTasks(userId);
    const preferences = await getNotificationPreferences(userId);

    if (!preferences.taskOverdue) return 0;

    let notificationsSent = 0;

    for (const task of overdueTasks) {
      const alreadySent = await hasNotificationBeenSentToday(userId, task.id, 'task_overdue');
      if (alreadySent) continue;

      const dueDate = new Date(task.dueDate);
      const now = new Date();
      const daysOverdue = Math.floor((now - dueDate) / (1000 * 60 * 60 * 24));

      const transaction = await getTransactionById(userId, task.transactionId);
      const user = await getUserById(userId);

      const templateData = {
        firstName: user?.displayName?.split(' ')[0] || 'there',
        taskTitle: task.title,
        taskDescription: task.description,
        dueDate: dueDate.toLocaleDateString(),
        daysOverdue: daysOverdue.toString(),
        priority: task.priority,
        transactionName: transaction?.propertyAddress || 'Your Transaction',
        tasksLink: `${window.location.origin}/tasks`
      };

      await createNotification(userId, {
        type: 'task_overdue',
        title: `OVERDUE: ${task.title}`,
        body: `${task.title} is ${daysOverdue} days overdue`,
        taskId: task.id,
        transactionId: task.transactionId,
        urgent: true
      });

      if (preferences.emailNotifications && user?.email) {
        await sendEmailNotification(user.email, 'taskOverdue', templateData);
      }

      if (preferences.smsNotifications && user?.phone) {
        await sendSmsNotification(user.phone, 'taskOverdue', templateData);
      }

      await logNotificationTrigger(userId, 'task_overdue', {
        taskId: task.id,
        taskTitle: task.title,
        daysOverdue: daysOverdue
      });

      notificationsSent++;
    }

    return notificationsSent;
  } catch (error) {
    console.error('Error checking overdue tasks:', error);
    return 0;
  }
};

/**
 * Check for closing approaching (7 days) and send notifications
 * @param {string} userId - The user ID
 * @returns {Promise<number>} - Number of notifications sent
 */
export const checkClosingApproaching7d = async (userId) => {
  try {
    const database = getDatabase(db);
    const transactionsRef = ref(database, `users/${userId}/transactions`);
    // Simplified - in production would use proper Firebase query

    const preferences = await getNotificationPreferences(userId);
    if (!preferences.closingReminders) return 0;

    let notificationsSent = 0;

    // This would be implemented with proper Firebase queries
    // For now, this is a placeholder that would be called periodically

    return notificationsSent;
  } catch (error) {
    console.error('Error checking 7d closing reminders:', error);
    return 0;
  }
};

/**
 * Check for closing approaching (3 days) and send urgent notifications
 * @param {string} userId - The user ID
 * @returns {Promise<number>} - Number of notifications sent
 */
export const checkClosingApproaching3d = async (userId) => {
  try {
    const preferences = await getNotificationPreferences(userId);
    if (!preferences.closingReminders) return 0;

    let notificationsSent = 0;

    // This would be implemented with proper Firebase queries
    // Check transactions where closing/lease start date is within 3 days

    return notificationsSent;
  } catch (error) {
    console.error('Error checking 3d closing reminders:', error);
    return 0;
  }
};

/**
 * Send transaction created notification
 * @param {string} userId - The user ID
 * @param {object} transaction - The newly created transaction
 * @returns {Promise<void>}
 */
export const sendTransactionCreatedNotification = async (userId, transaction) => {
  try {
    const preferences = await getNotificationPreferences(userId);
    if (!preferences.transactionUpdates) return;

    const user = await getUserById(userId);
    const tasks = await getTasksByTransaction(userId, transaction.id);

    const closingDate = transaction.closingDate || transaction.desiredClosingDate || transaction.leaseStartDate;

    const templateData = {
      firstName: user?.displayName?.split(' ')[0] || 'there',
      type: transaction.type,
      propertyAddress: transaction.propertyAddress || transaction.address || 'Your Property',
      createdDate: new Date().toLocaleDateString(),
      totalTasks: tasks.length.toString(),
      pendingTasks: tasks.filter(t => t.status === 'pending').length.toString(),
      transactionLink: `${window.location.origin}/transactions/${transaction.id}`,
      tasksLink: `${window.location.origin}/tasks`,
      agentName: 'Kelly Olin',
      agentPhone: '239-488-5900',
      agentEmail: 'Kelly.Olin@eXpRealty.com'
    };

    await createNotification(userId, {
      type: 'transaction_created',
      title: `${transaction.type} Transaction Created`,
      body: `Your ${transaction.type} transaction has been created with ${tasks.length} tasks`,
      transactionId: transaction.id
    });

    if (preferences.emailNotifications && user?.email) {
      await sendEmailNotification(user.email, 'transactionCreated', templateData);
    }

    if (preferences.smsNotifications && user?.phone) {
      await sendSmsNotification(user.phone, 'transactionCreated', templateData);
    }

    await logNotificationTrigger(userId, 'transaction_created', {
      transactionId: transaction.id,
      transactionType: transaction.type
    });
  } catch (error) {
    console.error('Error sending transaction created notification:', error);
    // Don't throw - notification failures shouldn't break transaction creation
  }
};

/**
 * Run all notification checks for a user
 * Typically called periodically by a background job or scheduled task
 * @param {string} userId - The user ID
 * @returns {Promise<object>} - Summary of notifications sent
 */
export const runNotificationChecks = async (userId) => {
  try {
    console.log(`Running notification checks for user: ${userId}`);

    const results = {
      reminders24h: await checkTaskReminders24h(userId),
      reminders1h: await checkTaskReminders1h(userId),
      overdue: await checkOverdueTasks(userId),
      closing7d: await checkClosingApproaching7d(userId),
      closing3d: await checkClosingApproaching3d(userId),
      totalSent: 0,
      timestamp: new Date().toISOString()
    };

    results.totalSent = results.reminders24h + results.reminders1h + results.overdue + results.closing7d + results.closing3d;

    console.log(`Notification check complete for ${userId}:`, results);
    return results;
  } catch (error) {
    console.error('Error running notification checks:', error);
    return {
      error: error.message,
      timestamp: new Date().toISOString()
    };
  }
};

export default {
  checkTaskReminders24h,
  checkTaskReminders1h,
  checkOverdueTasks,
  checkClosingApproaching7d,
  checkClosingApproaching3d,
  sendTransactionCreatedNotification,
  runNotificationChecks
};
