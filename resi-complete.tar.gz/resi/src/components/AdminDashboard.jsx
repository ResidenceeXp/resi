import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, TrendingUp, AlertCircle, CheckCircle2, Clock, DollarSign, Settings } from 'lucide-react';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedAgent, setSelectedAgent] = useState(null);

  const stats = [
    { label: 'Active Transactions', value: '24', icon: TrendingUp, color: 'amber' },
    { label: 'Total Revenue (YTD)', value: '$2.4M', icon: DollarSign, color: 'green' },
    { label: 'Team Members', value: '8', icon: Users, color: 'blue' },
    { label: 'Avg Days on Market', value: '18', icon: Clock, color: 'purple' },
  ];

  const agents = [
    { id: 1, name: 'Kelly Olin', transactions: 12, revenue: '$980K', closingRate: 94 },
    { id: 2, name: 'Amanda Bolduc', transactions: 8, revenue: '$640K', closingRate: 92 },
    { id: 3, name: 'Carrie Cabrera', transactions: 5, revenue: '$320K', closingRate: 88 },
    { id: 4, name: 'Liz Harris', transactions: 4, revenue: '$280K', closingRate: 90 },
  ];

  const recentTransactions = [
    { id: 'TXN-2024-089', property: '456 Corkscrew Ln', agent: 'Kelly Olin', status: 'closing', daysLeft: 2 },
    { id: 'TXN-2024-088', property: '123 Verdana Way', agent: 'Amanda Bolduc', status: 'inspection', daysLeft: 5 },
    { id: 'TXN-2024-087', property: '789 Kingston Dr', agent: 'Carrie Cabrera', status: 'undercontract', daysLeft: 12 },
    { id: 'TXN-2024-086', property: '321 Estero Blvd', agent: 'Liz Harris', status: 'pending', daysLeft: 3 },
  ];

  const systemAlerts = [
    { id: 1, type: 'warning', message: 'TXN-2024-089 closing in 2 days - final walkthrough needed' },
    { id: 2, type: 'info', message: 'New user Briggs Olin pending approval in admin dashboard' },
    { id: 3, type: 'success', message: 'TXN-2024-085 closed successfully - funds transferred' },
  ];

  const getStatusColor = (status) => {
    const colors = {
      closing: 'bg-green-50 border-green-200 text-green-900',
      inspection: 'bg-blue-50 border-blue-200 text-blue-900',
      undercontract: 'bg-amber-50 border-amber-200 text-amber-900',
      pending: 'bg-slate-50 border-slate-200 text-slate-900',
    };
    return colors[status] || colors.pending;
  };

  const getStatusLabel = (status) => {
    const labels = {
      closing: 'Closing',
      inspection: 'Inspection',
      undercontract: 'Under Contract',
      pending: 'Pending',
    };
    return labels[status] || status;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-slate-900 mb-2">Admin Dashboard</h1>
              <p className="text-slate-600">RESIDENCE | eXp Realty Team Management</p>
            </div>
            <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <Settings className="w-5 h-5 text-slate-600" />
              <span className="text-slate-900 font-medium">Settings</span>
            </button>
          </div>

          {/* Key Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {stats.map((stat, idx) => {
              const Icon = stat.icon;
              const colorClasses = {
                amber: 'bg-amber-50 border-amber-200 text-amber-600',
                green: 'bg-green-50 border-green-200 text-green-600',
                blue: 'bg-blue-50 border-blue-200 text-blue-600',
                purple: 'bg-purple-50 border-purple-200 text-purple-600',
              };
              return (
                <div key={idx} className={`${colorClasses[stat.color]} border rounded-lg p-4`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-600 mb-1">{stat.label}</p>
                      <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                    </div>
                    <Icon className="w-8 h-8 opacity-50" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-slate-200">
          {['overview', 'agents', 'transactions', 'alerts'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-medium transition-colors ${
                activeTab === tab
                  ? 'text-amber-600 border-b-2 border-amber-600'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Team Performance */}
            <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Team Performance</h2>
              <div className="space-y-4">
                {agents.map(agent => (
                  <div key={agent.id} className="flex items-center justify-between pb-4 border-b border-slate-200 last:border-0">
                    <div>
                      <p className="font-medium text-slate-900">{agent.name}</p>
                      <p className="text-sm text-slate-600">{agent.transactions} active transactions</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-slate-900">{agent.revenue}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="w-24 bg-slate-200 rounded-full h-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: `${agent.closingRate}%` }}
                          />
                        </div>
                        <span className="text-sm text-slate-600">{agent.closingRate}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button
                  onClick={() => navigate('/commissions')}
                  className="w-full bg-yellow-50 hover:bg-yellow-100 text-yellow-900 font-medium py-2 px-4 rounded-lg transition-colors">
                  View Commissions
                </button>
                <button className="w-full bg-amber-50 hover:bg-amber-100 text-amber-900 font-medium py-2 px-4 rounded-lg transition-colors">
                  Add Transaction
                </button>
                <button className="w-full bg-blue-50 hover:bg-blue-100 text-blue-900 font-medium py-2 px-4 rounded-lg transition-colors">
                  Invite Agent
                </button>
                <button className="w-full bg-green-50 hover:bg-green-100 text-green-900 font-medium py-2 px-4 rounded-lg transition-colors">
                  View Reports
                </button>
                <button
                  onClick={() => navigate('/admin/agent-settings')}
                  className="w-full bg-purple-50 hover:bg-purple-100 text-purple-900 font-medium py-2 px-4 rounded-lg transition-colors">
                  Agent Settings
                </button>
                <button className="w-full bg-slate-50 hover:bg-slate-100 text-slate-900 font-medium py-2 px-4 rounded-lg transition-colors">
                  Team Settings
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Agents Tab */}
        {activeTab === 'agents' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Team Members</h2>
            <div className="space-y-4">
              {agents.map(agent => (
                <div
                  key={agent.id}
                  onClick={() => setSelectedAgent(selectedAgent?.id === agent.id ? null : agent)}
                  className="p-4 border border-slate-200 rounded-lg hover:border-amber-300 cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-bold text-slate-900">{agent.name}</h3>
                    <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium">
                      Active
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Transactions</p>
                      <p className="text-2xl font-bold text-slate-900">{agent.transactions}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Revenue</p>
                      <p className="text-2xl font-bold text-green-600">{agent.revenue}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Closing Rate</p>
                      <p className="text-2xl font-bold text-blue-600">{agent.closingRate}%</p>
                    </div>
                  </div>
                  {selectedAgent?.id === agent.id && (
                    <div className="mt-4 pt-4 border-t border-slate-200">
                      <button className="text-amber-600 font-medium text-sm hover:text-amber-700">Edit Profile</button>
                      <span className="mx-2 text-slate-300">•</span>
                      <button className="text-slate-600 font-medium text-sm hover:text-slate-900">View Activity</button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Transactions Tab */}
        {activeTab === 'transactions' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Recent Transactions</h2>
            <div className="space-y-3">
              {recentTransactions.map(txn => (
                <div key={txn.id} className={`flex items-center justify-between p-4 rounded-lg border ${getStatusColor(txn.status)}`}>
                  <div className="flex-1">
                    <p className="font-medium">{txn.property}</p>
                    <p className="text-sm opacity-75">{txn.agent}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium mb-1">{getStatusLabel(txn.status)}</p>
                    <p className="text-xs opacity-75">{txn.daysLeft} days remaining</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Alerts Tab */}
        {activeTab === 'alerts' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-6">System Alerts</h2>
            <div className="space-y-3">
              {systemAlerts.map(alert => {
                const icons = {
                  warning: <AlertCircle className="w-5 h-5 text-amber-600" />,
                  info: <Clock className="w-5 h-5 text-blue-600" />,
                  success: <CheckCircle2 className="w-5 h-5 text-green-600" />,
                };
                const bgColors = {
                  warning: 'bg-amber-50 border-amber-200',
                  info: 'bg-blue-50 border-blue-200',
                  success: 'bg-green-50 border-green-200',
                };
                return (
                  <div key={alert.id} className={`flex items-start gap-3 p-4 rounded-lg border ${bgColors[alert.type]}`}>
                    {icons[alert.type]}
                    <div className="flex-1">
                      <p className="text-slate-900 font-medium">{alert.message}</p>
                    </div>
                    <button className="text-slate-600 hover:text-slate-900 text-sm font-medium">Dismiss</button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;