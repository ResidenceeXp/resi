import React, { useState } from 'react';
import { User, Phone, Mail, DollarSign, Calendar, FileText, CheckCircle2, AlertCircle } from 'lucide-react';

const BuyerInputForm = ({ transactionId = 'TXN-2024-001', onSubmit = null }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    buyerType: 'relocating',
    preApprovalAmount: '',
    downPayment: '',
    loanAmount: '',
    closingTimeline: '30-45',
    propertyType: '',
    desiredPrice: '',
    desiredLocation: '',
    specialRequirements: '',
    agentNotes: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    if (onSubmit) onSubmit(formData);
  };

  const isFormValid = formData.firstName && formData.lastName && formData.email && formData.phone;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Buyer Information</h1>
          <p className="text-slate-600">Transaction ID: {transactionId}</p>
        </div>

        {submitted && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-green-900">Buyer information saved successfully</p>
              <p className="text-sm text-green-800 mt-1">All details have been added to the transaction</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <User className="w-5 h-5 text-amber-600" />
              <h2 className="text-xl font-bold text-slate-900">Personal Information</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">First Name *</label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  placeholder="John"
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Last Name *</label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  placeholder="Smith"
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="john@example.com"
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Phone *
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="239-555-0123"
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Buyer Profile */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Buyer Profile</h2>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">Buyer Type</label>
              <div className="space-y-2">
                {[
                  { value: 'firsttime', label: 'First-Time Buyer' },
                  { value: 'relocating', label: 'Relocating / Moving to Southwest Florida' },
                  { value: 'secondhome', label: 'Second Home / Investment' },
                  { value: 'investor', label: 'Investment Property' },
                  { value: 'other', label: 'Other' },
                ].map(option => (
                  <label key={option.value} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 cursor-pointer">
                    <input
                      type="radio"
                      name="buyerType"
                      value={option.value}
                      checked={formData.buyerType === option.value}
                      onChange={handleChange}
                      className="w-4 h-4 text-amber-600"
                    />
                    <span className="text-slate-700">{option.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Financing Information */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <DollarSign className="w-5 h-5 text-amber-600" />
              <h2 className="text-xl font-bold text-slate-900">Financing Information</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Pre-Approval Amount</label>
                <input
                  type="text"
                  name="preApprovalAmount"
                  value={formData.preApprovalAmount}
                  onChange={handleChange}
                  placeholder="$750,000"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Down Payment</label>
                <input
                  type="text"
                  name="downPayment"
                  value={formData.downPayment}
                  onChange={handleChange}
                  placeholder="20%"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Loan Amount</label>
                <input
                  type="text"
                  name="loanAmount"
                  value={formData.loanAmount}
                  onChange={handleChange}
                  placeholder="$600,000"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Property Preferences */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Property Preferences</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Property Type</label>
                <select
                  name="propertyType"
                  value={formData.propertyType}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  <option value="">Select property type...</option>
                  <option value="singlefamily">Single Family Home</option>
                  <option value="condo">Condo</option>
                  <option value="townhome">Townhome</option>
                  <option value="newconstruction">New Construction</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Desired Price Range</label>
                <input
                  type="text"
                  name="desiredPrice"
                  value={formData.desiredPrice}
                  onChange={handleChange}
                  placeholder="$600K - $900K"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-slate-700 mb-2">Desired Location(s)</label>
              <input
                type="text"
                name="desiredLocation"
                value={formData.desiredLocation}
                onChange={handleChange}
                placeholder="e.g., Corkscrew, Verdana Village, Kingston"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Timeline */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <Calendar className="w-5 h-5 text-amber-600" />
              <h2 className="text-xl font-bold text-slate-900">Timeline</h2>
            </div>

            <label className="block text-sm font-medium text-slate-700 mb-3">Desired Closing Timeline</label>
            <div className="space-y-2">
              {[
                { value: '15-30', label: 'ASAP (15-30 days)' },
                { value: '30-45', label: '30-45 days' },
                { value: '45-60', label: '45-60 days' },
                { value: '60+', label: '60+ days (flexible)' },
              ].map(option => (
                <label key={option.value} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 cursor-pointer">
                  <input
                    type="radio"
                    name="closingTimeline"
                    value={option.value}
                    checked={formData.closingTimeline === option.value}
                    onChange={handleChange}
                    className="w-4 h-4 text-amber-600"
                  />
                  <span className="text-slate-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <FileText className="w-5 h-5 text-amber-600" />
              <h2 className="text-xl font-bold text-slate-900">Additional Information</h2>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Special Requirements or Notes</label>
              <textarea
                name="specialRequirements"
                value={formData.specialRequirements}
                onChange={handleChange}
                placeholder="Any specific needs, preferences, or special requirements..."
                rows="3"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-slate-700 mb-2">Agent Notes</label>
              <textarea
                name="agentNotes"
                value={formData.agentNotes}
                onChange={handleChange}
                placeholder="Internal agent notes..."
                rows="3"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={!isFormValid}
              className={`flex-1 py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 ${
                isFormValid
                  ? 'bg-amber-600 hover:bg-amber-700 text-white'
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              Save Buyer Information
            </button>
            <button
              type="button"
              className="px-6 py-3 border border-slate-300 rounded-lg font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BuyerInputForm;